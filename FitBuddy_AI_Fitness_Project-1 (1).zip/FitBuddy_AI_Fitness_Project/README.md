# FitBuddy - AI Fitness/WELLNESS Plan Generator Using Gemini

## 1. Project overview
FitBuddy is a Flask web application that collects basic student preferences and uses the Google Gemini API to generate a structured weekly movement and general wellness plan.

The project demonstrates:
- HTML/CSS frontend
- Python Flask backend
- Gemini API integration
- Structured JSON generation
- SQLite database storage
- Basic input validation

## 2. Requirements
- Python 3.10+
- Internet connection for Gemini API calls
- Gemini API key

## 3. Installation

### Windows
Open CMD in this project folder:

```text
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and put your Gemini API key in it.

Then run:

```text
python app.py
```

Open the address shown by Flask, normally:

```text
http://127.0.0.1:5000
```

## 4. Gemini API key
Create/manage a Gemini API key through Google AI Studio. Keep the key private and never upload `.env` to GitHub.

## 5. Project flow
User -> HTML Form -> Flask -> Gemini API -> JSON plan -> SQLite -> Result page

## 6. Database
Table: `plans`

Fields:
- id
- name
- age
- goal
- activity_level
- interests
- available_time
- plan_json
- created_at

## 7. Viva questions
1. What is Flask?
2. What is Gemini?
3. Why is an API used?
4. What is JSON?
5. Why is SQLite used?
6. What is prompt engineering?
7. Why do we use environment variables for API keys?
8. What is structured output?
9. What is the role of HTML/CSS?
10. How does the frontend communicate with the backend?

## 8. Safety scope
This student project intentionally avoids weight-loss targets, calorie restriction, supplements, medical treatment, and dangerous exercise challenges. It is a demonstration of AI application development rather than a medical or clinical system.
