import json
import os
import sqlite3
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "fitbuddy-dev-key")
DB_NAME = "fitbuddy.db"
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")


def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            goal TEXT NOT NULL,
            activity_level TEXT NOT NULL,
            interests TEXT NOT NULL,
            available_time INTEGER NOT NULL,
            plan_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def generate_plan(data):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Add it to the .env file before generating an AI plan."
        )

    client = genai.Client(api_key=api_key)

    prompt = f"""
You are FitBuddy, a safety-first wellness planning assistant for students.

Create a simple, age-appropriate weekly movement and wellness plan from these inputs:
Name: {data['name']}
Age: {data['age']}
Goal: {data['goal']}
Activity level: {data['activity_level']}
Interests: {data['interests']}
Available time per day: {data['available_time']} minutes

Important safety rules:
- Do not provide weight-loss, calorie-deficit, body-size, or appearance advice.
- Do not prescribe supplements, medicines, or medical treatment.
- Avoid dangerous challenges, extreme exercise, or unsafe intensity.
- Prefer enjoyable, moderate activities, rest/recovery, hydration, sleep, and general wellness.
- If the user reports pain, injury, dizziness, breathing difficulty, or another concerning symptom, advise stopping and speaking to a parent/guardian, teacher, coach, or healthcare professional.
- Keep activities suitable for a student and do not require gym equipment.
- This is general educational wellness information, not medical advice.

Return ONLY valid JSON matching the requested schema.
"""

    schema = {
        "type": "object",
        "properties": {
            "summary": {"type": "string"},
            "safety_note": {"type": "string"},
            "days": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "day": {"type": "string"},
                        "activity": {"type": "string"},
                        "duration": {"type": "string"},
                        "warmup": {"type": "string"},
                        "cooldown": {"type": "string"},
                        "wellness_tip": {"type": "string"}
                    },
                    "required": [
                        "day", "activity", "duration",
                        "warmup", "cooldown", "wellness_tip"
                    ]
                }
            }
        },
        "required": ["summary", "safety_note", "days"]
    }

    response = client.models.generate_content(
        model=MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=schema,
            temperature=0.7,
        ),
    )

    return json.loads(response.text)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate():
    try:
        name = request.form.get("name", "").strip()
        age = int(request.form.get("age", "0"))
        goal = request.form.get("goal", "").strip()
        activity_level = request.form.get("activity_level", "").strip()
        interests = request.form.get("interests", "").strip()
        available_time = int(request.form.get("available_time", "0"))

        if not name or not goal or not activity_level or not interests:
            raise ValueError("Please complete all fields.")
        if not 13 <= age <= 19:
            raise ValueError("For this student project, enter an age from 13 to 19.")
        if not 10 <= available_time <= 60:
            raise ValueError("Available time must be between 10 and 60 minutes.")

        data = {
            "name": name,
            "age": age,
            "goal": goal,
            "activity_level": activity_level,
            "interests": interests,
            "available_time": available_time,
        }

        plan = generate_plan(data)

        conn = get_db()
        conn.execute(
            """INSERT INTO plans
               (name, age, goal, activity_level, interests, available_time, plan_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                name, age, goal, activity_level, interests, available_time,
                json.dumps(plan), datetime.now().isoformat(timespec="seconds")
            ),
        )
        conn.commit()
        conn.close()

        return render_template("result.html", user=data, plan=plan)

    except Exception as exc:
        flash(str(exc))
        return redirect(url_for("index"))


@app.route("/history")
def history():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM plans ORDER BY id DESC LIMIT 20"
    ).fetchall()
    conn.close()
    return render_template("history.html", rows=rows)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
