# FITBUDDY - AI FITNESS PLAN GENERATOR USING GEMINI MODELS

## ABSTRACT
FitBuddy is an AI-enabled web application designed to demonstrate personalized wellness-plan generation using Google's Gemini models. The system accepts basic user preferences such as age, goals, activity level, preferred activities, and available time. The backend sends a carefully designed prompt to Gemini and requests a structured JSON response. The application then displays the generated weekly plan and stores a record in SQLite.

The project demonstrates practical integration of Artificial Intelligence with web development. It combines a user-friendly frontend, a Python Flask backend, a generative AI API, structured data generation, and a relational database.

## 1. INTRODUCTION
Artificial Intelligence is increasingly used to provide personalized digital assistance. Generative AI models can understand natural-language instructions and produce useful structured responses. FitBuddy applies this idea to a student-friendly wellness-planning application.

## 2. PROBLEM STATEMENT
Generic activity suggestions may not match a user's interests, available time, or current activity level. A simple AI-based system can accept these preferences and generate a flexible plan in a readable format.

## 3. OBJECTIVES
1. Develop a web-based AI wellness planner.
2. Integrate a Gemini model through an API.
3. Generate structured weekly plans.
4. Store generated plan records using SQLite.
5. Provide a simple and responsive user interface.
6. Demonstrate safe prompt design and input validation.

## 4. EXISTING SYSTEM
Traditional systems often display fixed lists of exercises or static schedules. Such systems do not dynamically adapt the content to user preferences.

## 5. PROPOSED SYSTEM
FitBuddy collects user preferences and uses Gemini to generate a structured plan dynamically. The application validates basic inputs, stores the result, and presents the plan through a web interface.

## 6. MODULES
### 6.1 User Input Module
Collects name, age, goal, activity level, interests, and available time.

### 6.2 AI Module
Creates a prompt and sends it to Gemini.

### 6.3 Structured Output Module
Requests JSON fields for summary, safety note, daily activity, duration, warm-up, cool-down, and wellness tip.

### 6.4 Database Module
Stores generated plans in SQLite.

### 6.5 Presentation Module
Displays the generated plan using HTML and CSS.

## 7. SYSTEM REQUIREMENTS
### Hardware
- Computer/laptop
- 4 GB RAM or above
- Internet connection

### Software
- Python 3.10+
- Flask
- Google GenAI Python SDK
- SQLite
- VS Code or another code editor
- Modern web browser

## 8. SYSTEM ARCHITECTURE

User
  |
  v
Web Browser
  |
  v
Flask Application
  |
  +----> Input Validation
  |
  +----> Gemini API
  |          |
  |          v
  |      Structured JSON
  |
  +----> SQLite Database
  |
  v
Result Web Page

## 9. DATA FLOW
1. User opens FitBuddy.
2. User enters preferences.
3. Flask receives form data.
4. Flask validates the values.
5. A safety-focused prompt is created.
6. Gemini generates JSON.
7. The JSON is parsed.
8. The plan is stored in SQLite.
9. The result is displayed.

## 10. DATABASE DESIGN

Table: plans

| Field | Type | Description |
|---|---|---|
| id | INTEGER | Primary key |
| name | TEXT | User name |
| age | INTEGER | User age |
| goal | TEXT | Selected goal |
| activity_level | TEXT | Activity level |
| interests | TEXT | Preferred activities |
| available_time | INTEGER | Minutes available |
| plan_json | TEXT | Generated JSON |
| created_at | TEXT | Creation time |

## 11. ALGORITHM
1. Start.
2. Display the FitBuddy form.
3. Read user input.
4. Validate required fields.
5. Create a safety-focused Gemini prompt.
6. Send the prompt to Gemini.
7. Receive structured JSON.
8. Parse the JSON.
9. Store the plan in SQLite.
10. Display the weekly plan.
11. Stop.

## 12. ADVANTAGES
- Easy to use.
- AI-generated personalized content.
- Structured output is easy to display.
- Stores previous generated plans.
- Demonstrates real API integration.

## 13. LIMITATIONS
- Requires internet access for Gemini.
- Requires a valid Gemini API key.
- AI output still needs application-level validation.
- It is not a medical or clinical system.

## 14. FUTURE ENHANCEMENTS
- User login.
- Admin dashboard.
- Progress journal.
- Reminder notifications.
- Multilingual interface.
- Export plan as PDF.
- More detailed validation and moderation.
- Cloud database deployment.

## 15. CONCLUSION
FitBuddy demonstrates how a generative AI model can be integrated into a web application to produce structured, personalized wellness content. The project combines frontend development, backend programming, API integration, prompt design, JSON processing, and database management.

## 16. REFERENCES
1. Google AI for Developers - Gemini API documentation.
2. Python Flask documentation.
3. SQLite documentation.
4. HTML/CSS web standards documentation.
